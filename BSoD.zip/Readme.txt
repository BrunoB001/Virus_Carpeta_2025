Este archivo es semi-peligroso, ¡ten cuidado en ejecutarlo COMO ADMINISTRADOR!
PD:
	Contraseña: wy8gr762erg5ue