¡Mi segundo "virus" visual!
Si te gusta el Minecraft y los terremotos, ¡este "virus" es para ti!
/!\ Aviso para los epilépticos /!\