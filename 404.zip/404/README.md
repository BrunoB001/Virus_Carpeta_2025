#############################
#                           #
#    #  #   #####      #  # #
#   #   #  #     #    #   # #
#  #    #  #     #   #    # #
# #######  #     #  ####### #
#       #  #     #        # #
#       #   #####         # #
#                           #
#############################

Creado por: Brunito001
Rango de destrucción: muy alto (404.exe), nulo (404_safety.exe)
Creado para: Windows 7/8.x/10/11
Creado en: C# & .NET Framework 4.7.2

---------------------------------------------------------------------------------------

¡Hola!

Creo que vienes a ejecutar 404.exe

Pero antes debo avisarte de que NUNCA debes ejecutarlo en un dispositivo real, 
a no ser que sea la versión safety

Y también te aviso de que tampoco debes ejecutarlo si sufres de epilepsia fotosensible,
ya que este troyano Win32 viene cargado de efectos visuales y de sonido

Ejecútalo con cuidado, ya que el creador (yo) no se hace responsable de los daños

¡Buena suerte!
