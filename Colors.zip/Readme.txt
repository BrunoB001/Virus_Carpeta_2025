Este es mi primer virus visual creado con .NET Framework en C#.
Tiene 3 efectos visuales, y si puedes, cuando te canses de los efectos, puedes finalizar este proceso con "taskmgr.exe", y si no puedes, reinicia la PC, o apágala y vuelve a encenderla.
¡Te aseguro que será muy bonito y épico! (Aún así, aviso para los epilépticos).