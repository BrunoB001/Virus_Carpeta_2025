Esto es un ransomware, ¡ten cuidado manejándolo!
¡Gracias por leerme!